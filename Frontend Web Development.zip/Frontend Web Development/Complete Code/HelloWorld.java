class ABC{
    public static void main(String arg[]
    {
        system.out.println("Hello World");
    })
}